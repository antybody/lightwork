package com.tgb.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tgb.framework.db.DbContextHolder;
import com.tgb.model.User;
import com.tgb.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	/**
	 * 获取所有用户列表
	 * @param request
	 * @return
	 */
	@RequestMapping("/findAll")
	public String findAll(HttpServletRequest request){
		List<Map<String,String>> list=userService.findAll3();
		request.setAttribute("findAll", list);
		return "showUser";
	}
	
	/**
	 * 切换数据源oracle
	 * @param request
	 * @return
	 */
	@RequestMapping("/oracle")
	public String oracle(HttpServletRequest request){
		DbContextHolder.setDbType("dataSource1"); 
		List<Map<String,String>> list=userService.findAll3();
		request.setAttribute("findAll", list);
		return "showUser";
	}
	
	/**
	 * 切换数据源 mysql
	 * @param request
	 * @return
	 */
	@RequestMapping("/mysql")
	public String mysql(HttpServletRequest request){
		DbContextHolder.setDbType("dataSource2"); 
		List<Map<String,String>> list=userService.findAll3();
		request.setAttribute("findAll", list);
		return "showUser";
	}
}
