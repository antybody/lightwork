package com.tgb.framework.db;

import java.util.logging.Logger;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
public class DynamicDataSource extends AbstractRoutingDataSource {

	/** 
     * 取得当前使用那个数据源。 
     */  
    @Override  
    protected Object determineCurrentLookupKey() {  
    	String str=DbContextHolder.getDbType();
        return str;    
    }  
  
      
    public Logger getParentLogger() {  
        // TODO Auto-generated method stub  
        return null;  
    }  
 
}
