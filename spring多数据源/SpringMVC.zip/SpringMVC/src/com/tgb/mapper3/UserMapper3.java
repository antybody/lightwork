package com.tgb.mapper3;

import java.util.List;
import java.util.Map;

public interface UserMapper3 {
	List<Map<String,String>> findAll();
}
