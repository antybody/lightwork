package com.tgb.service;

import java.util.List;
import java.util.Map;

import com.tgb.model.User;


public interface UserService {
	List<Map<String,String>> findAll3();
}
