package com.tgb.threads;

public class concurrent extends Thread {
    public void run(){
    	System.out.println(getName()+"是一个演员！");
    	int count =0;
    	
    	boolean keepRuning = true;
    	
    	while(keepRuning){
    	   System.out.println(getName()+"登台演出" +(++count));
    	   
    	   if(count == 100)
    		   keepRuning = false;
    	   
    	   if(count%10 == 0){
    		   try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    	   }
    	}
    	System.out.println(getName()+"的演出结束了！");
    	
    }
    
    public static void main(String[] args){
    	Thread concurrent = new concurrent();
    	concurrent.setName("Mr.Thread");
    	concurrent.start();
    }
}
