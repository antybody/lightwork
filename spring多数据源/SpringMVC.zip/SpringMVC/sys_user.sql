/*
Navicat MySQL Data Transfer

Source Server         : iwater
Source Server Version : 50528
Source Host           : 121.42.166.210:8085
Source Database       : iwater

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2017-03-16 16:56:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `ui_id` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '主键',
  `add_date` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '添加时间',
  `up_date` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '修改时间',
  `user_info` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '操作者',
  `user_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '账户',
  `user_pwd` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '密码',
  `user_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '真实姓名',
  `user_mail` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '邮箱',
  `user_post` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '职务',
  `user_tel` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '联系电话(手)',
  `user_phone` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '联系电话(座)',
  `del_modified` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '删除标志位',
  PRIMARY KEY (`ui_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('117F07684ACC40B68F60B64F24B3239B', '2017-03-01 10:14:28', '2017-03-02 09:53:35', 'admin', 'tingyu', '$2a$10$90qg6A5JJ81uRWA.vcidEexazLdzaTiKh3SxRyy58njW5fkJ9/tzm', '张无忌', 'yu@baosight.com', 'user_post_001', '13652636325', '0716-5896262', '1');
INSERT INTO `sys_user` VALUES ('A2A614F1C7014B29B750C2AE931DCBF0', '2017-02-24 15:40:49', '2017-03-02 10:22:32', 'admin', 'admin', '$2a$10$viRepHg.Zt9JxBC3o8vxneRXC1zO3zW82jbCVR232CsLD2hbcR7La', '管理员', 'baosight@shanshan.com', 'user_post_001', '13685828585', '071685959696', '1');
INSERT INTO `sys_user` VALUES ('F74C5BED394340F3970C56908E00E653', '2017-03-13 15:15:02', '2017-03-13 15:26:14', 'admin', 'gaoh', '$2a$10$XUcKl0efN6PigH55ruNgxergdSRoeFEjGsyA5OZK9tk9o5b5sAuHK', 'gaoh', '', 'user_post_004', '15611111111', '', '1');
INSERT INTO `sys_user` VALUES ('FDD214DA26C04C9A8CDDBE91C1D3D323', '2017-02-17 11:22:06', '2017-02-28 15:49:41', null, 'ym', '$2a$10$d2uxDkoJRdTTTTMnqoPbbuAJqQPAgcjVTNkw0/ufHXZ7SikUz0F.e', '袁敏', '', '001', '15921593569', '', '1');
